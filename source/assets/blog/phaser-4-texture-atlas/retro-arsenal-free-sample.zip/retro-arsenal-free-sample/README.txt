Retro Arsenal free sample

To run the demo, serve this folder and open index.html:
  npx serve .        or        python3 -m http.server
(Opening index.html straight from disk won't work: browsers block loading
the atlas from file://.)

Files
  retro_arsenal_sample.png   3072 x 1024 atlas, 3 frames
  retro_arsenal_sample.json  JSON hash atlas data with pivot and muzzle points
  main.js                    the Phaser 4 demo
  index.html                 loads Phaser 4.2.1 from a CDN, then main.js

Tutorial: https://tekisolves.github.io/blog/phaser-4-texture-atlas/
